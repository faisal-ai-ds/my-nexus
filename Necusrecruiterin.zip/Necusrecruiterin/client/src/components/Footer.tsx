import { Link } from "wouter";
import { Phone, Globe, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">RecruitNexus</h3>
            <p className="text-background/80 leading-relaxed">
              Your Nexus for Talent. Connecting organizations with skilled professionals
              who drive business success.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <Link href="/">
                <a className="text-background/80 hover:text-background transition-colors" data-testid="footer-link-home">
                  Home
                </a>
              </Link>
              <br />
              <Link href="/about">
                <a className="text-background/80 hover:text-background transition-colors" data-testid="footer-link-about">
                  About Us
                </a>
              </Link>
              <br />
              <Link href="/industries">
                <a className="text-background/80 hover:text-background transition-colors" data-testid="footer-link-industries">
                  Industries Served
                </a>
              </Link>
              <br />
              <Link href="/services">
                <a className="text-background/80 hover:text-background transition-colors" data-testid="footer-link-services">
                  Services
                </a>
              </Link>
              <br />
              <Link href="/contact">
                <a className="text-background/80 hover:text-background transition-colors" data-testid="footer-link-contact">
                  Contact Us
                </a>
              </Link>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-background/80">
                <Phone className="w-5 h-5" />
                <span>+91 961 968 4605</span>
              </li>
              <li className="flex items-center gap-2 text-background/80">
                <Globe className="w-5 h-5" />
                <span>www.recruitnexus.in</span>
              </li>
              <li className="flex items-start gap-2 text-background/80">
                <MapPin className="w-5 h-5 mt-1" />
                <span>7/1, Horizon Heights, Kasarvadavli,<br />Ghodbunder Road, Thane West</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 pt-6 text-center text-background/80">
          <p>&copy; {new Date().getFullYear()} RecruitNexus. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
