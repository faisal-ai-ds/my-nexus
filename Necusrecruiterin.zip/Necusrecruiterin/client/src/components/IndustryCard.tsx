import { Card } from "@/components/ui/card";

interface IndustryCardProps {
  image: string;
  title: string;
  tagline: string;
  description: string;
}

export default function IndustryCard({ image, title, tagline, description }: IndustryCardProps) {
  return (
    <Card className="overflow-hidden hover-elevate active-elevate-2 transition-all duration-300 h-full flex flex-col" data-testid={`card-industry-${title.toLowerCase()}`}>
      <div className="aspect-video w-full overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6 flex-1 flex flex-col">
        <h3 className="text-2xl font-semibold text-foreground mb-2" data-testid={`text-industry-title-${title.toLowerCase()}`}>
          {title}
        </h3>
        <p className="text-primary text-lg italic mb-4" data-testid={`text-industry-tagline-${title.toLowerCase()}`}>
          {tagline}
        </p>
        <p className="text-muted-foreground leading-relaxed flex-1" data-testid={`text-industry-description-${title.toLowerCase()}`}>
          {description}
        </p>
      </div>
    </Card>
  );
}
