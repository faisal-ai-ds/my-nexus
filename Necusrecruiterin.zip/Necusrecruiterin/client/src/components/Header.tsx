import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import logoImage from "@assets/IMG-20251009-WA0008_1760216497296.jpg";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();

  const menuItems = [
    { path: "/", label: "Home" },
    { path: "/about", label: "About Us" },
    { path: "/industries", label: "Industries Served" },
    { path: "/services", label: "Services" },
    { path: "/contact", label: "Contact Us" },
  ];

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-40 bg-background/95 backdrop-blur-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center" data-testid="link-home">
            <img src={logoImage} alt="RecruitNexus Logo" className="h-12 md:h-14 w-auto" />
          </Link>

          <Button
            size="icon"
            variant="ghost"
            onClick={toggleMenu}
            data-testid="button-menu-toggle"
            className="hover-elevate active-elevate-2"
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>
      </header>

      {isMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-50"
          onClick={closeMenu}
          data-testid="backdrop-menu"
        />
      )}

      <div
        className={`fixed top-0 right-0 h-screen w-80 bg-background shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${
          isMenuOpen ? "translate-x-0" : "translate-x-full"
        }`}
        data-testid="menu-panel"
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-6 border-b">
            <h2 className="text-xl font-semibold">Menu</h2>
            <Button
              size="icon"
              variant="ghost"
              onClick={closeMenu}
              data-testid="button-menu-close"
              className="hover-elevate active-elevate-2"
            >
              <X className="h-6 w-6" />
            </Button>
          </div>

          <nav className="flex-1 p-6">
            <ul className="space-y-2">
              {menuItems.map((item) => (
                <li key={item.path}>
                  <Link href={item.path} onClick={closeMenu}>
                    <button
                      data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                      className={`w-full text-left px-4 py-3 rounded-md text-lg font-medium transition-colors hover-elevate active-elevate-2 ${
                        location === item.path
                          ? "text-primary border-l-4 border-primary"
                          : "text-foreground"
                      }`}
                    >
                      {item.label}
                    </button>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </>
  );
}
