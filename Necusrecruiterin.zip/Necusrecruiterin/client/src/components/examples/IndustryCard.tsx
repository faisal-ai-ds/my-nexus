import IndustryCard from "../IndustryCard";
import industryImage from "@assets/IMG-20251009-WA0009_1760216567018.jpg";

export default function IndustryCardExample() {
  return (
    <div className="p-8 bg-background">
      <IndustryCard
        image={industryImage}
        title="Banking"
        tagline="Powering Financial Futures"
        description="We connect banks, financial institutions, and fintech firms with professionals skilled in risk management, compliance, operations, and customer service."
      />
    </div>
  );
}
