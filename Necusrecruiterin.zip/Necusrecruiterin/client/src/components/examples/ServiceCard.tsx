import ServiceCard from "../ServiceCard";
import { FileText } from "lucide-react";

export default function ServiceCardExample() {
  return (
    <div className="p-8 bg-background">
      <ServiceCard
        icon={FileText}
        title="Resume Writing"
        description="Professional, ATS-ready resumes that showcase skills and achievements."
      />
    </div>
  );
}
