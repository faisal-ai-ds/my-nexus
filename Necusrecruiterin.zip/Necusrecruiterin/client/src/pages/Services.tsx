import ServiceCard from "@/components/ServiceCard";
import {
  FileText,
  FileType,
  Database,
  Users,
  CheckCircle,
  UserCheck,
  Calendar,
  UserPlus,
  Settings,
  Briefcase,
} from "lucide-react";
import servicesImage from "@assets/Screenshot_20251011_110803_M365 Copilot_1760217134942.jpg";

export default function Services() {
  const supportingServices = [
    {
      icon: FileText,
      title: "Resume Writing",
      description: "Professional, ATS-ready resumes that showcase skills and achievements.",
    },
    {
      icon: FileType,
      title: "Document Conversion",
      description: "Convert reports, resumes, and files into polished, client-ready formats.",
    },
    {
      icon: Database,
      title: "Data Entry",
      description: "Accurate, secure data handling to support HR and operational needs.",
    },
    {
      icon: Users,
      title: "Pipeline Building",
      description: "Maintain a steady flow of qualified candidates for current and future hiring.",
    },
    {
      icon: CheckCircle,
      title: "Verification Services",
      description: "Background, employment, and credential checks to ensure candidate credibility.",
    },
    {
      icon: UserCheck,
      title: "Candidate Screening",
      description: "Evaluate skills, experience, and cultural fit to shortlist the best talent.",
    },
    {
      icon: Calendar,
      title: "Interview Coordination",
      description: "Manage scheduling, communication, and logistics for smooth interviews.",
    },
    {
      icon: UserPlus,
      title: "Onboarding Support",
      description: "Help new hires integrate quickly with documentation and orientation.",
    },
    {
      icon: Settings,
      title: "Custom Solutions",
      description: "Tailored hiring strategies for bulk recruitment, niche skills, and executive searches.",
    },
  ];

  return (
    <div className="min-h-screen">
      <section className="relative bg-gradient-to-br from-chart-5 via-primary to-chart-1 text-primary-foreground py-32 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-page-title">
            Our Services
          </h1>
          <p className="text-xl text-primary-foreground/90 max-w-3xl mx-auto" data-testid="text-page-subtitle">
            Comprehensive recruitment solutions tailored to your needs
          </p>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-primary/10 mb-6">
                <Briefcase className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground" data-testid="text-section-main">
                End-to-End Recruitment
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed" data-testid="text-main-description">
                We manage the complete hiring process, from sourcing and screening to interviews and onboarding. We find the right talent, ensure cultural fit, and deliver professionals who drive business results.
              </p>
            </div>
            <div>
              <img
                src={servicesImage}
                alt="End-to-End Recruitment Services"
                className="w-full h-auto rounded-lg shadow-lg"
                data-testid="img-services"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-card">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-section-supporting">
            Supporting Services
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {supportingServices.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6 text-foreground" data-testid="text-section-approach">
            Our Approach
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed" data-testid="text-approach-description">
            Every service is designed to create value at each stage of the hiring journey. We combine industry expertise, modern tools, and a relationship-first mindset to deliver professionals who make an impact from day one.
          </p>
        </div>
      </section>
    </div>
  );
}
