import { Router } from "wouter";
import About from "../About";

export default function AboutExample() {
  return (
    <Router>
      <About />
    </Router>
  );
}
