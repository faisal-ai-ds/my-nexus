import { Router } from "wouter";
import Services from "../Services";

export default function ServicesExample() {
  return (
    <Router>
      <Services />
    </Router>
  );
}
