import { Router } from "wouter";
import Industries from "../Industries";

export default function IndustriesExample() {
  return (
    <Router>
      <Industries />
    </Router>
  );
}
