import { CheckCircle2 } from "lucide-react";
import aboutImage from "@assets/Screenshot_20251011_110723_M365 Copilot_1760217057468.jpg";

export default function About() {
  const values = [
    "We prioritize integrity, transparency, and long-term relationships in every engagement.",
    "We combine data-driven insights with personal attention to match the right talent with the right organization.",
    "We focus on understanding people, culture, and business goals to ensure every placement adds value.",
    "We maintain a fast, efficient process while keeping communication clear and consistent.",
  ];

  const reasons = [
    "Clients trust us to deliver skilled professionals who drive business results.",
    "Candidates rely on us to find opportunities that match their skills, goals, and career growth.",
    "Our industry expertise ensures informed, precise hiring decisions.",
    "We build lasting partnerships, not just transactions, creating mutual success for organizations and talent.",
  ];

  return (
    <div className="min-h-screen">
      <section className="relative bg-gradient-to-br from-chart-5 via-primary to-chart-1 text-primary-foreground py-32 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-page-title">
            About RecruitNexus
          </h1>
          <p className="text-xl text-primary-foreground/90 max-w-3xl mx-auto" data-testid="text-page-subtitle">
            Connecting Organizations. Building Futures.
          </p>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-foreground" data-testid="text-section-story">
                Our Story
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p data-testid="text-story-1">
                  RecruitNexus is a talent sourcing and recruitment partner focused on delivering skilled professionals who drive business success. We connect organizations with the right talent through a data-driven and relationship-based approach.
                </p>
                <p data-testid="text-story-2">
                  Our expertise covers Banking, Finance, Learning and Development, Manufacturing, and Information Technology. We understand the talent needs unique to each industry and help employers build teams that perform with consistency and integrity.
                </p>
                <p data-testid="text-story-3">
                  At RecruitNexus, we believe hiring is more than filling positions. It is about understanding people, culture, and long-term goals. Our sourcing specialists combine market insight with personal attention to ensure every placement adds value to both client and candidate.
                </p>
                <p data-testid="text-story-4">
                  We are committed to transparent processes, quick turnaround, and lasting partnerships. Whether you are scaling your business or advancing your career, RecruitNexus is your nexus for talent.
                </p>
              </div>
            </div>
            <div>
              <img
                src={aboutImage}
                alt="RecruitNexus - Where Talent Meets Opportunity"
                className="w-full h-auto rounded-lg shadow-lg"
                data-testid="img-about"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-card">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-section-values">
            Values and Approach
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {values.map((value, index) => (
              <div key={index} className="flex gap-4" data-testid={`item-value-${index}`}>
                <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <p className="text-muted-foreground leading-relaxed">{value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-section-choose">
            Clients and Candidates Choose Us
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {reasons.map((reason, index) => (
              <div key={index} className="flex gap-4" data-testid={`item-reason-${index}`}>
                <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <p className="text-muted-foreground leading-relaxed">{reason}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-gradient-to-br from-primary to-chart-1 text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6" data-testid="text-section-values-summary">
            Our Values
          </h2>
          <p className="text-lg leading-relaxed" data-testid="text-values-summary">
            Integrity, transparency, and long-term relationships guide everything we do. We combine market insight with personal attention to connect the right people with the right opportunities.
          </p>
        </div>
      </section>

      <section className="py-20 px-6 bg-card">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground" data-testid="text-section-why-summary">
            Why Choose RecruitNexus
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed" data-testid="text-why-summary">
            We deliver skilled professionals who drive results. Clients trust us for precise, industry-focused hiring. Candidates rely on us to find roles that match their skills and goals. Every placement creates lasting impact.
          </p>
        </div>
      </section>
    </div>
  );
}
