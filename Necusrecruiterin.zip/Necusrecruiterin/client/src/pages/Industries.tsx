import IndustryCard from "@/components/IndustryCard";
import industryImage from "@assets/Screenshot_20251011_110824_M365 Copilot_1760217207552.jpg";

export default function Industries() {
  const industries = [
    {
      title: "Banking",
      tagline: "Powering Financial Futures",
      description:
        "We connect banks, financial institutions, and fintech firms with professionals skilled in risk management, compliance, operations, and customer service. Our candidates understand regulatory frameworks and can drive efficiency and growth in complex banking environments.",
    },
    {
      title: "Finance",
      tagline: "Fueling Growth & Strategy",
      description:
        "We source talent for investment management, corporate finance, accounting, and financial planning roles. Our candidates combine technical expertise with strategic insight to support financial objectives and business growth.",
    },
    {
      title: "Healthcare",
      tagline: "Elevating Patient Care",
      description:
        "We recruit clinical staff, healthcare administrators, and management professionals for hospitals, clinics, and healthcare service providers. Our candidates ensure high standards of patient care, operational efficiency, and regulatory compliance.",
    },
    {
      title: "Manufacturing",
      tagline: "Crafting Tomorrow's World",
      description:
        "We provide skilled professionals for production, quality control, supply chain, and operations management. Our candidates understand industrial processes, compliance standards, and lean management practices to enhance productivity and maintain quality.",
    },
    {
      title: "Information Technology",
      tagline: "Innovating Digital Horizons",
      description:
        "We deliver professionals in software development, IT infrastructure, cybersecurity, and digital transformation. Our candidates bring technical expertise, problem-solving skills, and adaptability to support innovation and business growth.",
    },
  ];

  return (
    <div className="min-h-screen">
      <section className="relative bg-gradient-to-br from-chart-5 via-primary to-chart-1 text-primary-foreground py-32 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-page-title">
            Industries Served
          </h1>
          <p className="text-xl text-primary-foreground/90 max-w-3xl mx-auto" data-testid="text-page-subtitle">
            Connecting industries that drive growth
          </p>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto mb-16">
          <img
            src={industryImage}
            alt="Industries Served Overview"
            className="w-full h-auto rounded-lg shadow-lg"
            data-testid="img-industries-overview"
          />
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {industries.map((industry, index) => (
              <IndustryCard
                key={index}
                image={industryImage}
                title={industry.title}
                tagline={industry.tagline}
                description={industry.description}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-card">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6 text-foreground" data-testid="text-section-commitment">
            Our Commitment to Excellence
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed" data-testid="text-commitment-description">
            We find talent that fits, not just fills. Our deep industry knowledge and commitment to understanding your unique business needs ensure that every placement drives real value and lasting success.
          </p>
        </div>
      </section>
    </div>
  );
}
