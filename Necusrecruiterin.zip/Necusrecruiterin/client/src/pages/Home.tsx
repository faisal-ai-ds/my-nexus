import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import logoImage from "@assets/IMG-20251009-WA0008_1760216497296.jpg";
import industryImage1 from "@assets/IMG-20251009-WA0009_1760216567018.jpg";
import industryImage2 from "@assets/IMG-20251009-WA0010_1760216567039.jpg";
import aboutImage from "@assets/Screenshot_20251011_110723_M365 Copilot_1760217057468.jpg";

export default function Home() {
  return (
    <div className="min-h-screen">
      <section className="relative bg-gradient-to-br from-chart-5 via-primary to-chart-1 text-primary-foreground py-32 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <img src={logoImage} alt="RecruitNexus" className="h-24 md:h-28 w-auto mx-auto mb-8" data-testid="img-logo" />
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight" data-testid="text-hero-title">
            Welcome to RecruitNexus
          </h1>
          <p className="text-xl md:text-2xl mb-4 text-primary-foreground/90" data-testid="text-hero-subtitle">
            Your Nexus for Talent
          </p>
          <p className="text-lg md:text-xl mb-8 text-primary-foreground/80 max-w-3xl mx-auto" data-testid="text-hero-tagline">
            Connecting Organizations. Building Futures.
          </p>
          <Link href="/contact">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-6" data-testid="button-get-started">
              Get Started <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-section-intro">
            Welcome to RecruitNexus – Your Nexus for Talent
          </h2>
          <div className="prose prose-lg max-w-4xl mx-auto text-muted-foreground">
            <p className="text-lg leading-relaxed mb-6" data-testid="text-intro-description">
              At RecruitNexus, we deliver end-to-end recruitment solutions that connect organizations with the right professionals. We focus on finding talent who not only have the skills but also align with your company's culture and long-term goals.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-card">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 text-foreground" data-testid="text-section-expertise">
            Our Expertise
          </h2>
          <p className="text-lg text-center text-muted-foreground mb-12 max-w-4xl mx-auto leading-relaxed" data-testid="text-expertise-description">
            We specialize in Banking, Finance, Healthcare, Manufacturing, and IT. Our industry knowledge ensures precise, high-quality hiring that drives performance and growth.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <img
              src={industryImage1}
              alt="Industries We Serve"
              className="w-full h-auto rounded-lg shadow-lg"
              data-testid="img-industries-1"
            />
            <img
              src={industryImage2}
              alt="Talent Connection"
              className="w-full h-auto rounded-lg shadow-lg"
              data-testid="img-industries-2"
            />
          </div>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 text-foreground" data-testid="text-section-services">
            Our Services
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-4xl mx-auto mb-12" data-testid="text-services-description">
            We manage the complete hiring process, from sourcing and screening to interviews and onboarding. Supporting services include resume writing, document conversion, data entry, talent pipeline building, verification, candidate screening, interview coordination, onboarding support, and custom recruitment solutions tailored to your business needs.
          </p>
          <div className="text-center">
            <Link href="/services">
              <Button variant="default" size="lg" data-testid="button-view-services">
                View All Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-card">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 text-foreground" data-testid="text-section-why">
            Why Choose Us
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-4xl mx-auto text-center" data-testid="text-why-description">
            We combine data-driven strategies with personal attention. Our transparent processes, fast turnaround, and relationship-focused approach create lasting value for both clients and candidates.
          </p>
        </div>
      </section>

      <section className="py-20 px-6 bg-gradient-to-br from-primary to-chart-1 text-primary-foreground">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6" data-testid="text-section-partner">
            Partner with RecruitNexus
          </h2>
          <p className="text-lg mb-8 max-w-3xl mx-auto leading-relaxed" data-testid="text-partner-description">
            Whether you are scaling your business or advancing your career, RecruitNexus ensures you connect with the right talent or opportunity every time.
          </p>
          <Link href="/contact">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-6" data-testid="button-contact-cta">
              Contact Us Today
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
